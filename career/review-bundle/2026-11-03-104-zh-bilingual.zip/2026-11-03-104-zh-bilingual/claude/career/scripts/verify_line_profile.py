#!/usr/bin/env python3
"""驗收 LINE 英文履歷／Profile（line-resume.md、line-profile.md）。

用法：python3 career/scripts/verify_line_profile.py <檔> [--for verify|pack|pdf] [--upstream <上游 md>]
- 格式契約與解析由 line_md.py 共用（產生器同一份），用途不支援的格式在這裡就拒絕。
- 語氣與錨點只檢查對外正文（HTML 註解剔除）。
- 事實保存：給 --upstream 才核對數字＋單位、限定詞、完成狀態與 LOCK_ENTITIES；沒給就明確標示「未核對」。
  固定英文措辭存在≠事實完整或語意正確；責任與因果仍需主代理人工查核。"""
import json, re, sys
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
import fact_lock  # noqa: E402
import line_md  # noqa: E402

ENUM = {
    "employment_type": {"1194", "1195"},
    "type_of_degree": {"20", "21", "22", "23"},
    "degree_status": {"1172", "1173", "2559"},
    "language": {"10", "14", "273", "18", "272", "15", "16"},
    "country": {"215", "110", "117", "233"},
    **{k: {"33", "1174", "34", "35", "36"} for k in ("written", "spoken", "reading", "listening")},
}
FIELDS = {
    "basic": ["email", "mobile_phone", "current_position_title", "current_employer", "country", "address", "city"],
    "work_experience": ["company", "position_title", "employment_type", "location", "start_date", "end_date"],
    "education": ["degree_name", "type_of_degree", "degree_status", "university", "start_date", "end_date"],
    "languages": ["language", "written", "spoken", "reading", "listening"],
}
BANNED = ["strategic", "passionate", "detail-oriented", "leverage", "robust", "seamlessly", "delve", "Spearheaded",
          "Backed by", ", which leave", "merge request", "my planners", "guided my planners", "guided direct-report planners through",
          "launched in 2018/05", "launched in 2018-05", "planned a group function for large employers", "proven track record", "cutting-edge", "(to consolidate", "govern the underlying data fields", "Reverse-engineered", "reverse-engineer", "In March–April 2026", "workflow with human review", "Consolidated categories across teams", "guided product planners", "guided the product planners", "assigned others to product planners", "assigned others to the planners", "Present", "Singapore", "Russia", "1111 Job Bank"]
BANNED_BULLET_ONLY = BANNED[:-1]

ANCHORS = {
    "2.1": ["Analyzed and mapped", "743 of 840 related client requests", "sales buy-in", "department or branch", "lower the barrier", "candidate matching", "compliance",
            "actual selections", "shared category code tables", "underlying data fields", "field-level mappings", "direct reports", "delegated", "renewal", "credibility", "at least 30 days"],
    "2.2": ["Airbnb", "Miro", "kicked off in 2018", "Led the design"],
}
DATE = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
D = re.compile(r"<!-- @line-directive\s*(\{.*?\})\s*-->", re.S)


def upstream_check(doc, up_path):
    """與指定上游逐區塊核對：Summary、每個 directive 的列點。回傳 (errors, manual)。"""
    up_text = __import__("pathlib").Path(up_path).read_text(encoding="utf-8")
    up = line_md.parse(up_text)
    errs, manual = [], []
    pairs = []
    if up["summary"] is not None:
        pairs.append(("Summary", up["summary"], doc["summary"] or ""))
    ud, dd = up["directives"], doc["directives"]
    if len(ud) != len(dd):
        errs.append(f"[來源對帳] directive 數量與上游不同：上游 {len(ud)}、成品 {len(dd)}")
    for i, (a, b) in enumerate(zip(ud, dd)):
        name = f"{a['d'].get('target_block')}#{a['d'].get('index', 0)}"
        if a["d"].get("fields") != b["d"].get("fields"):
            errs.append(f"[來源對帳] {name} 表單欄位與上游不同")
        if len(a["bullets"]) != len(b["bullets"]):
            errs.append(f"[來源對帳] {name} 列點數 {len(b['bullets'])}，上游 {len(a['bullets'])}")
        pairs.append((name, "\n".join(a["bullets"]), "\n".join(b["bullets"])))
    for name, u, d in pairs:
        e, m = fact_lock.compare_block(u, d)
        errs += [f"{x} @ {name}" for x in e]
        manual += [f"{name}：{x}" for x in m]
    for ent in re.findall(r"\[LOCK_ENTITIES:\s*([^\]]*)\]", up_text):
        for w in [x.strip() for x in ent.split(",") if x.strip()]:
            if w not in line_md.visible(__import__("pathlib").Path(doc["_path"]).read_text(encoding="utf-8")):
                errs.append(f"[鎖定詞遺失] 上游 LOCK_ENTITIES「{w}」不在成品對外正文")
    return errs, manual


def main(path, purpose="verify", upstream=None):
    t = __import__("pathlib").Path(path).read_text(encoding="utf-8")
    doc = line_md.parse(t)
    doc["_path"] = path
    errs = line_md.validate(doc, purpose)
    seen = {}
    for item in doc["directives"]:
        d = item["d"]
        if not isinstance(d, dict) or d.get("target_block") not in FIELDS or not isinstance(d.get("fields"), dict):
            continue
        b, f = d.get("target_block"), d.get("fields", {})
        for k, v in f.items():
            if not isinstance(v, str):
                errs.append(f"{b}.{k} 必須為字串")
                continue
            if k in ENUM and v not in ENUM[k]:
                errs.append(f"{b}.{k}={v!r} 不在 Enum 白名單")
            if k.endswith("date"):
                if k == "end_date" and v == "":
                    pass
                elif not DATE.match(v):
                    errs.append(f"{b}.{k}={v!r} 非 YYYY-MM")
            if re.search(r"[^\x00-\x7f]", v):
                errs.append(f"{b}.{k} 含非英文字元：{v!r}")
        if b == "work_experience" and f.get("end_date") not in ("",) and f.get("end_date", "") < f.get("start_date", ""):
            errs.append(f"work_experience index {d.get('index')} 結束早於開始")
    t = line_md.visible(t) + "\n" + "\n".join(  # 以下語氣與錨點只看對外正文；directive 另以 doc 檢查
        f"<!-- @line-directive {json.dumps(i['d'], ensure_ascii=False)} -->" for i in doc["directives"] if isinstance(i["d"], dict))
    # 在職者 end_date 必為空：標題含 Present 的區塊
    for h in re.finditer(r"^### [^\n]*Present[^\n]*\n+<!-- @line-directive\s*(\{.*?\})\s*-->", t, re.M | re.S):
        if json.loads(h.group(1))["fields"].get("end_date") != "":
            errs.append("在職（Present）區塊 end_date 必須為空字串")
    # Bullet 禁用詞（只查 - 開頭行）
    for i, line in enumerate(t.splitlines(), 1):
        if line.startswith("- "):
            for w in BANNED_BULLET_ONLY:
                if w.lower() in line.lower():
                    errs.append(f"第 {i} 行含禁用詞「{w}」")
            if re.search(r"[一-鿿]", line):
                errs.append(f"第 {i} 行 Bullet 含中文")
    # 體裁與句型（voice-en §8）
    heads = [l for l in t.splitlines() if re.match(r"^## (Editing Notes|English Self-Review)", l)]
    if heads:
        errs.append("[成品污染] 不得含 " + "、".join(h[3:] for h in heads) + "：修改紀錄寫於對話回覆，勿寫入本檔")
    bullets = [l for l in t.splitlines() if l.startswith("- ")]
    i_cnt = sum(len(re.findall(r"\bI\b", l)) for l in bullets)
    if i_cnt > 3:
        errs.append(f'[英文履歷體裁違規] 全篇 Bullet 出現高達 {i_cnt} 次第一人稱 "I"（上限 3 次）！英文履歷列點請採用外商標準 Implied First-Person（省略主詞 I，直接以動詞或場景子句接過去式動詞）！')
    for_cnt = sum(1 for l in bullets if l.startswith("- For "))
    prev_blk, prev_w = None, None
    repeat = False
    blk = None
    for l in t.splitlines():
        if l.startswith("### "):
            blk, prev_w = l, None
        elif l.startswith("- "):
            w = l[2:].split(" ", 1)[0].strip(",:").lower()
            if prev_w is not None and w == prev_w:
                repeat = True
            prev_w = w
    if for_cnt > 2 or repeat:
        errs.append(f"[AI 句首模板違規] 偵測到過多或連續重複的句首詞（For 開頭 {for_cnt} 點，上限 2；同區塊連續同字開頭={repeat}），請打散句首結構！")
    if sum(1 for l in bullets if l.count("(") >= 2 and re.search(r"\((?:to|in) [a-z]", l)) :
        errs.append("[規則備註括號] Bullet 內有解釋性括號堆疊，請改寫成正文")
    # 英文履歷結構與格式（voice-en §11、§12）
    if re.search(r"personal statement|autobiography", t, re.I):
        errs.append("[英文履歷結構] 不得含 PERSONAL STATEMENT／Autobiography 區塊（外商英文履歷只放 Summary、Skills、Experience、Education、Languages）")
    if re.search(r"Kun Huai Nie\b(?!h)", t):
        errs.append("[姓名拼法] 英文姓名須為 Kun Huai Nieh（漏 h）")
    for i, line in enumerate(t.splitlines(), 1):
        if not line.startswith("- "):
            continue
        if re.search(r"\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}\b", line):
            errs.append(f"第 {i} 行內文用英文月份全稱：統一用 YYYY/MM（如 2026/03–04）")
        if re.search(r"\b\d{4}-\d{2}[-–]\d{4}-\d{2}\b", line):
            errs.append(f"第 {i} 行起訖日期缺少前後空格：須為 YYYY-MM – YYYY-MM")
        if re.match(r"- (In|On|During|Since|From) (the )?(\d{4}|January|February|March|April|May|June|July|August|September|October|November|December)", line):
            errs.append(f"第 {i} 行以日期開頭：動作／事件先行")
    for i, line in enumerate(t.splitlines(), 1):
        if re.match(r"#{2,3} .*\d{4}-\d{2}[-–]\d{4}-\d{2}", line):
            errs.append(f"第 {i} 行標題日期缺少前後空格")
    # Summary 數字不與列點重複；Skills Title Case；箭頭符號（voice-en §9、§13）
    if "## 0." in t and "## 1." in t:
        sec0 = t[t.index("## 0."):t.index("## 1.")]
        zero = [l[2:] for l in sec0.splitlines() if l.startswith("- ")]
        if zero:
            summary_nums = set(re.findall(r"(?<![\w])\d[\d,~.]*%?(?![\w])", zero[0])) - {"10"}
            rest = "\n".join(l for l in t.splitlines() if l.startswith("- ") and not l[2:].startswith("Product Owner with"))
            dup = [n for n in summary_nums if n in rest]
            if dup:
                errs.append(f"[跨欄重複數字] Summary 的數字 {dup} 已在列點出現；同一數字只留一處（本人 2026-11-01）")
        for l in zero[1:]:
            if ":" in l and not l.startswith("Languages"):
                items = [x.strip() for x in l.split(":", 1)[1].split(",")]
                bad = [x for x in items if x and not x[0].isupper()]
                if bad:
                    errs.append(f"[Skills 大小寫] 項目須 Title Case：{bad}")
    if "→" in t.split("## 1.")[-1] and any("→" in l for l in t.splitlines() if l.startswith("- ")):
        errs.append("[非 ASCII 箭頭] 列點不用 →（表單可能拒收）；改用 then／to")
    # AI 工具名前必帶類別詞（voice-en §9）
    body = "\n".join(l for l in t.splitlines() if not l.lstrip().startswith("<!--"))
    for m in re.finditer(r"Antigravity", body):
        ctx = body[max(0, m.start() - 100):m.start()]
        if not re.search(r"AI agents|Agentic AI|AI Agent", ctx, re.I):
            errs.append("[工具名無類別詞] Claude Code／Antigravity 前方須有 AI agents 或 Agentic AI Tools 類別詞（voice-en §9）")
            break
    # 商業價值錨點：避免中翻英降維（voice-en §7）
    for num, words in ANCHORS.items():
        m = re.search(r"^### %s\b.*?(?=^### |^---|\Z)" % re.escape(num), t, re.M | re.S)
        body = m.group(0).lower() if m else ""
        for w in words:
            if w.lower() not in body:
                errs.append(f"區塊 {num} 缺少必備錨點「{w}」（Credibility Stripping）")
    for m in D.finditer(t):
        a = json.loads(m.group(1)).get("fields", {}).get("address")
        if a and (a.endswith(".") or "St. Beitou" in a):
            errs.append(f"address 標點錯誤：{a!r}")
    for blk in ("basic", "work_experience", "education", "languages"):
        if blk not in {json.loads(m.group(1)).get("target_block") for m in D.finditer(t)}:
            errs.append(f"缺少區塊 {blk}")
    manual = []
    if upstream:
        try:
            ue, manual = upstream_check(doc, upstream)
            errs += ue
        except OSError as e:
            errs.append(f"[來源對帳] 無法讀取上游：{e}")
    print(f"格式：{doc['format']}；用途：{purpose}")
    if errs:
        print("❌ LINE 驗收失敗")
        for e in errs:
            print(" -", e)
        return 1
    print("✅ 格式與語氣規則通過")
    if upstream:
        print(f"✅ 事實保存：已與上游 {upstream} 核對數字＋單位、限定詞、完成狀態、LOCK_ENTITIES")
        for m in manual[:20]:
            print(" 🔎 人工查核：", m)
    else:
        print("⚠️ 事實保存：未核對（未提供 --upstream）；格式通過不代表事實完整")
    return 0


def cli(argv=None):
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--for", dest="purpose", default="verify", choices=sorted(line_md.PURPOSES))
    ap.add_argument("--upstream")
    try:
        a = ap.parse_args(argv)
    except SystemExit:
        return 2
    try:
        return main(a.file, a.purpose, a.upstream)
    except OSError as e:
        print(f"❌ 無法讀取：{e}")
        return 2


if __name__ == "__main__":
    sys.exit(cli())
