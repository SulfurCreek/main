---
name: resume-causal-logic-compiler
description: 專治履歷「概念偷跑（未定義先引用）」與「因果斷裂」問題。透過建立實體字典、強制單向依賴規則與邏輯審查閘門，確保每個 Bullet Point 具備獨立可讀性與嚴格的線性因果邏輯。
---
# Resume Causal Logic Compiler

## 語言路由（2026-11-02，本人指定：中英文履歷維度差很多，指令與工具互不影響）

事實層與編譯核心（本檔「Core Compiler Rules」「Execution Workflow」、library、Final Arbiter）**中英共用**；**語氣層分流**：

| 輸出語言 | 語氣與編譯護欄 | 語氣規範 | 驗證工具 |
| :-- | :-- | :-- | :-- |
| 中文（104 履歷、自傳、中文推薦信） | `references/zh-voice-guardrails.md` | `career/style/resume-voice-zh.md` | `scripts/verify_polish.py`、`scripts/verify_letter.py`（中文信） |
| 英文（LINE Resume／LinkedIn／英文 CV／英文條列） | `references/en-voice-guardrails.md` | `career/style/voice-en.md` | `scripts/verify_line_profile.py`、`scripts/verify_line_pdf.py`、`scripts/build_line_pdf.py` |

規則：**不互相套用**。中文的「建立／救回」計數、前 20 字、主導白名單、紅字與 Quill 排版屬中文；英文的 `I` 上限、`direct reports`、日期格式、2 頁上限、Title Case 屬英文。混合文件（例：中文推薦信含英文條列）中文段落走 zh、英文條列走 en。橋接規則只有一條：英文版必須完整保留對應中文版的商業目的、影響範圍與口徑（見 en 護欄〈跨語言一致性〉）。

## Core Compiler Rules (嚴格編譯規則)
1. **禁止前向引用 (No Forward Referencing)**：撰寫第 N 個 Bullet Point 時，絕對禁止直接使用第 N+1 個（或更後面）才會首次定義的系統名稱、專案代號或業務背景。
2. **首次提及必定義 (Define on First Use)**：任何內部專有名詞或系統在「第一次出現」時，必須附帶完整的上下文錨點（是什麼系統、服務什麼量級的受眾、解決什麼痛點）。
3. **單點獨立性測試 (Standalone Readability Test)**：假設把其他所有點遮住，只單獨讀當前這一點，外部 HR 也必須 100% 理解前因、動作與量化影響。
4. **敘事起點 LEAD（2026-10-23 取代舊「一律量化成果 (Result) ｜ 核心行動…」）**：依讀者理解所需決定起點與數字位置。
   - `[LEAD: RESULT]`：第一句已交代對象、指標與變化，讀者不必等後文才懂數字意義時採用（如 Peach 網頁付款占比、提案 30 天內結案比例）。
   - `[LEAD: ACTION]`：核心在本人負責的規劃、協作與交付，數字僅為補充交付量或規模時採用（如約 50 項功能上線，將交付量接在需求分析、規格與驗收協作之後）。
   - `[LEAD: CONTEXT]`：必須先理解使用者問題、既有系統限制、服務中斷事件或實驗對照設計，才能理解後續行動與數據時採用（如新版系統 840／743 件建議、199 件即時通與 55 件群組建議、JustDating／Juicy 下架承接、馬來西亞定價實驗）。
   - 產出 `causal_draft.md` 的 `NEEDS_POLISH` 標記時統一寫成：`<!-- [STATUS: NEEDS_POLISH] [LEAD: RESULT|ACTION|CONTEXT] [LOCK_ENTITIES: ...] -->`。
   - 數字放置：需求件數放問題背景旁；交付量接責任與行動；成效數據保留比較口徑及歸因。不強制全篇成果先行，也不一律把數字移到最後。詳見 Codex `voice_style_guide.md` §9。

5. **去日常流水帳、凸顯 PM 功績與破局難度（Impact & Stakes Framing，2026-10-24 本人新增，全篇適用）**：同時嚴守不捏造數據、不跨過 `OVERCLAIM_PATTERNS` 責任禁令。
   1. **禁止純行政與例行事務流水帳（No Chore Lists）**：正文不得單純羅列排甘特圖、送簽、結案確認、每週回報、處理翻譯、新增／編輯／刪除、依主管／公司政策等例行公事；每個動作都要綁定「解決什麼商業或系統限制（Stakes）」或「達成什麼產品與推進目的（Purpose）」。必須交代政策歸屬才能誠實解讀數字時，寫成限制條件（例如「在主管訂定的處理優先序下」），不寫成工作項目。
   2. **把內部專案代號轉成外部懂的戰略規模與破局難度**：例如「新版求才系統」要寫成企業端招募系統的全面翻新改版，交代沿用既有業務後台與底層資料庫、歷史權限與計費規則沒有文件的限制，以及逆向還原規則、重建流程與規格、分階段上線的作法與結果。
   3. **無營收數據的項目，以商業模式完整度／跨端規模／0 到 1 破局展現功績**：不可只列功能名稱或日常任務，要點出商業定位（例：建立涵蓋訂閱、點數與曝光的多元變現機制；統籌 7 個海外市場的產品在地化；在維持既有付費企業服務與新版改版並行的雙線需求下完成功能交付）。
   4. **不用內部行話**：工作中慣用的縮寫或行話（例：「刊案」）對外讀者不直覺，一律改寫成完整說法（例：「刊登合作邀約」）。
   5. **跨欄去重**：同一組成果數字不在全篇重複三次；工作經歷與專案成就（獨立卡片）可並列，自傳只寫判斷與做法（2026-10-24 本人選 B）。
   6. **事實不足就提問**：library 不足以寫出「為什麼有價值／解決什麼困難」時，不硬湊，依 Clarification Gate 向本人提問。

## Execution Workflow（2026-10-26 重構：提取事實 → 建立個人形象 → 檢查；本人指定）
每次修改 `career/01_claude_stage/causal_draft.md` 時，必須先在內部完成：

1. **Phase 1 — 事實提取與實體字典（Fact Extraction & Entity Dictionary）**：從 `facts-*.md`、`profile.md` 提取真實事件、限制、數據；盤點專有名詞的外部白話定義與首次解鎖位置，檢查拓撲順序（禁止前向引用，前面依賴後面定義者強制重排或前移定義）。嚴守 No Detail Dumping。
2. **Phase 2 — 建立個人形象與 Credibility 升維（Personal Brand & Credibility Framing）★**：動筆寫每個列點或段落前，先把事實對位到下列四大支柱之一，寫出「這件事證明本人哪種專業信譽」，不只記敘任務：

   | 支柱 | 定位 | library 依據 | 代表素材 |
   | --- | --- | --- | --- |
   | 1｜從混亂中建立可運作規則的破局者 | 無文件、無競品、分類發散時，釐清底層邏輯並建立跨單位可執行的規則 | `profile.md` §8「改規則前先把事實查清楚」「把一方的語言翻成另一方做得出來的規則」；`about-me.md` §四 1–2 | 1111 逆向還原帳號權限與商業模式規則；KOOL 無競品雙邊媒合；15 張類別代碼表跨單位合併收斂 |
   | 2｜守護營收、續約與實收的商業 PM | 把維護與改版錨定在商業價值 | `about-me.md` §三、§五〈尚凡產品的重要性〉；facts-1111 結案比例商業目的 | 52%→79% 為維護付費企業滿意度與續約基礎；主力高營收產品下架後承接用戶與營收；定價實驗與網頁付款以對照與費率試算保護實收 |
   | 3｜讓業務與跨部門買單的可靠樞紐 | 決定能向各方交代、轉換代價不丟給使用者 | `profile.md` §8「決定要能向各方交代」「系統改變的代價不該丟給使用者」 | 兩線搶資源先取得業務單位背書；建立產品團隊在業務單位的交付可信度；分階段替換、上線前客服封測；帶領直屬企劃、指導同仁用 AI |
   | 4｜AI 產品落地與人機協作治理者 | 呈現產品判斷，不只列功能或工具 | `about-me.md` §四〈AI Agent 與 human in the loop〉；facts-1111〈AI 功能品質把關〉 | 定義問題、勞動法規合規驗收、企業確認後才刊登的人工把關、依實際選用資料調整規則 |

   **護欄**：支柱是**框架，不是要塞進正文的口號**——不得出現「破局者」「Credibility」「治理者」等自我標籤；不得突破 `about-me.md` §四／§五 的「邊界」欄（例：不寫「沒有我就無法上線」、DAU 不歸個人、不寫毛利等 library 無紀錄的指標）；不違反 decisions §24 披露、§43／R16 概念詞（例：「分類治理」不入文）、No Detail Dumping 與責任詞規則。字數只能持平或變短。

   **鎖定詞瘦身**：`LOCK_ENTITIES` 只鎖 ①硬數據與日期期間 ②核心產品／系統專有名詞 ③代表四大支柱的關鍵價值詞（例：`商業模式規則`、`業務單位背書`、`付費企業`、`續約基礎`、`交付可信度`）。不鎖連接詞、工具名清單、瑣碎步驟，留給 Codex 重組句法。

3. **Phase 3 — 因果與字數護欄（Verification Gate）**：確認無未知黑話、無 `**粗體開頭：**`、標記正確（`NEEDS_POLISH`＋`LEAD`＋`LOCK_ENTITIES`，或 `LOCKED`）；主幹敘事淨字數 ≤165（Juicy 雙次承接 ≤190）；跑 `python3 career/scripts/verify_polish.py` 上游 0 違規。
4. **Phase 4（Self-Evolving Gatekeeper，2026-10-24 本人新增)**：
   - **三聯同步鐵律**：每當本人在對話中抓出任何事實偏差、日常流水帳寫法（Chore）、被動語態或下游幻覺詞時，嚴禁只修改單點草稿交差，必須同步完成三件事：
     1. **事實層**：更新 `career/library/`（`facts-*.md`／`decisions.md`／`superseded.md`）。
     2. **規則層**：將通用原則補充至 `resume-causal-logic-compiler/SKILL.md`（若涉及下游語氣，同步列出供 Codex 更新 `voice_style_guide.md`）。
     3. **驗證層（強制程式化回歸）**：若該問題可透過關鍵字、正規表達式或結構比對攔截，**必須當下同步更新 `career/scripts/verify_polish.py`**（加入 `CHORE_AND_HALLUCINATION_TOKENS`、`FORBIDDEN_104_TAGS` 或結構檢查），確保同一錯誤在全篇任何角落與未來版本都無法通過腳本。

---

## 附註（Career Move 增補，不影響上方原文；本人 2026-10-21／22 已裁定仍有效）

- **事實界線**：無 library 數字的點不估、不編，標〔待補數據〕交本人；本人是規劃／協作／驗收者，工程實作不歸本人，動詞不升級。
- **披露與跨欄位**：不寫投票名次、被延後項目、預計上線日期；進行中專案可寫狀態（本人 2026-10-22 允許信件與即時通寫「開發中」）；目標、提示文案、預期值不當成效；經歷移除的內容，專案／專長／自傳／簡介也不得殘留。
- **草稿結構**：`causal_draft.md` 的實體字典、拓撲大綱、檢查三節只供編輯，不屬於列點；成品（final_resume.md）不含這三節。
- **改寫比例（本人 2026-10-22）**：不強求改寫比例；`verify_polish.py` 相似度門檻 0.99，只攔原句照抄。
- **用詞檢查（本人 2026-10-22 裁定）**：文體詞（透過、藉由、賦能…）照禁；責任詞（協助、參與、配合、支援、維護）只警示，Codex 須對照 library 確認是真實責任並在修改紀錄說明；LOCKED 內不檢查。責任升級詞（主導、架構、扛下、開發、實作、重構）成品出現而上游同一點沒有 → 失敗；「主導」只有 library 確認的 Juicy、JustDating 重新上架可用，且須由上游草稿先寫出。實作見 `scripts/verify_polish.py`。 **2026-10-25 補**：「確立」「制定」同屬高強度責任詞；上級政策只能寫「依…原則」，不得寫成本人確立（例：結案比例點的客戶提案優先原則為上級政策）。
- 前版全文與本人原始版：`references/`（含 `previous-2026-10-21-claude-role-version.md`）。


## Pre-Questioning Lookup Gate（2026-10-25，本人指定）

提問前必先 grep `career/library/` 並讀 `decisions.md` §45〈已結案免追問清單〉。已有紀錄者直接引用；屬「依本人裁定不入正文」者不再問、不寫入草稿，標 `[已由 library/decisions 結案：已知事實，依本人裁定不入履歷正文，僅留作面試口頭回答]`。只有 library 確定無紀錄時才問，並寫明「已檢索 `library/` 無此紀錄」；答覆立即補進 §45。把審查建議轉成草稿前，先對照 decisions §24 披露規則（不寫未公開排序、延後項目、預計日期）。

## No Detail Dumping（2026-10-25，本人指定）

`library/` 的操作流程、Edge Case、內部溝通步驟只供查核與面試題庫。審查（HM01–HM14）指出的細節缺口不得自動從 `library/` 撈進草稿；預設列為面試口袋案例（decisions §45）。列點寫設計原則與商業目的，不寫 PRD 細則；工作經歷非母項的單一列點，剝除括號內統計期間後的淨字數 ≤165 字（含 Juicy 雙次承接點 ≤190 字；不含空白，`verify_polish.py` 的 `BULLET_LENGTH_CAP`）。

## Autonomous Review & Compile Loop（2026-10-25，本人指定）

本 skill 與 `resume-review-panel` 串成閉環：盲審 → 查 `library/` → A 類直接重編本草稿 → `verify_polish.py` 上游 0 違規 → 出 Codex 指令。A 類重編的硬護欄：事實只取自 library；只能變短或持平（淨字數 ≤165，Juicy ≤190）；不寫 PRD 細則（No Detail Dumping）；不推翻 decisions 本人裁定；LOCKED 段解鎖須附前後對照。B 類歸面試口袋案例，C 類（library 無紀錄）才提問。回報格式見 `career/CLAUDE.md` Stage 1 第 9 點。

## Pursuing Voice（中文專屬，內容已移至 `references/zh-voice-guardrails.md`；章節名保留以免既有引用失效）

## Anti-Over-Disclaimer（中文專屬，內容已移至 `references/zh-voice-guardrails.md`；章節名保留以免既有引用失效）

## 前 20 字張力（中文專屬，內容已移至 `references/zh-voice-guardrails.md`；章節名保留以免既有引用失效）

## 跨語言一致性護欄（英文專屬，內容已移至 `references/en-voice-guardrails.md`；章節名保留以免既有引用失效）

## 英文履歷職級感（英文專屬，內容已移至 `references/en-voice-guardrails.md`；章節名保留以免既有引用失效）

## 英文履歷結構（英文專屬，內容已移至 `references/en-voice-guardrails.md`；章節名保留以免既有引用失效）

